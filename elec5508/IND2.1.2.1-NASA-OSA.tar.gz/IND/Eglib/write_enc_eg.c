/***
 *** See the file "IND/disclaimers-and-notices.txt" for 
 *** information on usage and redistribution of this file, 
 *** and for a DISCLAIMER OF ALL WARRANTIES.
 ***/

/*IND-version2.0
 *   IND 2.0 released 9/15/92   
 *   NASA Ames Research Center, MS 269-2, Moffett Field, CA 94035
 */

#include <stdio.h>
#include "SYM.h"
#include "sets.h"

write_enc_eg(eg, outf)
egtype    eg;
FILE	*outf;
{
   	if ((fwrite((char *) eg.unordp, egsize, 1, outf)) < 1 )
       		uerror("Could not write to encoded example file","");
}

